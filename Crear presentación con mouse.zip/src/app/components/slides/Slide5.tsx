import { motion } from 'motion/react';
import { Smartphone, Monitor, UserCheck, CheckCircle2 } from 'lucide-react';

export default function Slide5() {
  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-950 via-blue-950/10 to-slate-950 flex flex-col justify-center px-20">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-12"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="h-1 w-12 bg-blue-500" />
          <span className="text-blue-400 uppercase tracking-wider text-sm font-medium">
            Prototipo y Usabilidad
          </span>
        </div>
        <h2 className="text-5xl font-bold text-white mb-4">
          Diseño Centrado en Usuario
        </h2>
        <p className="text-xl text-slate-400 max-w-3xl">
          Reducir errores humanos y facilitar la experiencia en ventanilla mediante interfaces claras y accesibles
        </p>
      </motion.div>

      <div className="grid grid-cols-2 gap-12 max-w-6xl">
        {/* Mockup Ciudadano */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.7 }}
          className="space-y-6"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center">
              <Smartphone className="w-7 h-7 text-blue-400" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">Interfaz Ciudadano</h3>
              <p className="text-sm text-slate-400">Pre-digitación móvil</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-950/30 to-slate-900/30 border border-blue-500/20 rounded-2xl p-8 backdrop-blur-sm">
            <div className="space-y-4">
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                    <UserCheck className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-white font-semibold">Datos del Viajero</span>
                </div>
                <div className="space-y-2 text-sm text-slate-400">
                  <div className="flex justify-between">
                    <span>RUT</span>
                    <span className="text-white">12.345.678-9</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Nombre</span>
                    <span className="text-white">María González</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Destino</span>
                    <span className="text-white">Argentina</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-white font-semibold">Validación en Tiempo Real</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-400">Documentos verificados</span>
                </div>
              </div>

              <button className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-4 rounded-xl transition-colors">
                Confirmar Pre-registro
              </button>
            </div>
          </div>
        </motion.div>

        {/* Mockup Funcionario */}
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.7 }}
          className="space-y-6"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
              <Monitor className="w-7 h-7 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">Interfaz Funcionario</h3>
              <p className="text-sm text-slate-400">Dashboard operativo</p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-emerald-950/30 to-slate-900/30 border border-emerald-500/20 rounded-2xl p-8 backdrop-blur-sm">
            <div className="space-y-4">
              <div className="bg-white/5 border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-white font-semibold">Trámites Pendientes</span>
                  <span className="bg-emerald-500/20 text-emerald-400 text-xs font-bold px-3 py-1 rounded-full">
                    12
                  </span>
                </div>
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center justify-between text-sm py-2 border-b border-white/5 last:border-0">
                      <span className="text-slate-400">Trámite #{i}234</span>
                      <span className="text-emerald-400 text-xs">Pre-validado</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="text-2xl font-bold text-white mb-1">87%</div>
                  <div className="text-xs text-slate-400">Datos completos</div>
                </div>
                <div className="bg-white/5 border border-white/10 rounded-lg p-3">
                  <div className="text-2xl font-bold text-white mb-1">-42%</div>
                  <div className="text-xs text-slate-400">Tiempo de proceso</div>
                </div>
              </div>

              <button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-4 rounded-xl transition-colors">
                Aprobar Lote
              </button>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
        className="mt-10 flex justify-center"
      >
        <div className="bg-slate-800/30 border border-slate-700/50 rounded-xl px-8 py-4 backdrop-blur-sm">
          <p className="text-slate-300 text-center">
            Colores institucionales <span className="text-blue-400 font-semibold">Azul</span>, <span className="text-slate-200 font-semibold">Blanco</span> y <span className="text-red-400 font-semibold">Rojo</span> | Diseño minimalista y accesible
          </p>
        </div>
      </motion.div>
    </div>
  );
}
