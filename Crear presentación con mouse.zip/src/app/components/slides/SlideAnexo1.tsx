import { motion } from 'motion/react';
import { Calendar, Users, Code, TestTube, Rocket } from 'lucide-react';

export default function SlideAnexo1() {
  const fases = [
    { fase: 'Semana 1-2', nombre: 'Planificación', icon: Calendar, items: ['Análisis de requerimientos', 'Arquitectura técnica', 'Definición de sprint'] },
    { fase: 'Semana 3-5', nombre: 'Desarrollo Sprint 1', icon: Code, items: ['Backend core', 'APIs base', 'Base de datos'] },
    { fase: 'Semana 6-8', nombre: 'Desarrollo Sprint 2', icon: Users, items: ['Frontend ciudadano', 'Frontend funcionario', 'Integraciones'] },
    { fase: 'Semana 9-10', nombre: 'Testing QA', icon: TestTube, items: ['Pruebas unitarias', 'Pruebas integración', 'UAT'] },
    { fase: 'Semana 11-12', nombre: 'Despliegue', icon: Rocket, items: ['Deploy producción', 'Capacitación', 'Documentación'] }
  ];

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex flex-col justify-center px-20">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-12"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="h-1 w-12 bg-slate-500" />
          <span className="text-slate-400 uppercase tracking-wider text-sm font-medium">
            Anexo 1 - Carta Gantt
          </span>
        </div>
        <h2 className="text-5xl font-bold text-white mb-4">
          Cronograma Detallado
        </h2>
        <p className="text-xl text-slate-400">
          12 semanas distribuidas en 5 fases iterativas
        </p>
      </motion.div>

      <div className="space-y-6 max-w-6xl">
        {fases.map((fase, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 + index * 0.1, duration: 0.6 }}
            className="flex items-start gap-6 group"
          >
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-blue-500/20 group-hover:border-blue-500/30 transition-colors">
                <fase.icon className="w-8 h-8 text-slate-400 group-hover:text-blue-400 transition-colors" />
              </div>
              {index < fases.length - 1 && (
                <div className="w-px h-16 bg-slate-700 mt-2" />
              )}
            </div>

            <div className="flex-1 pt-3">
              <div className="flex items-baseline gap-4 mb-3">
                <span className="text-sm text-slate-500 font-mono">{fase.fase}</span>
                <h3 className="text-2xl font-bold text-white">{fase.nombre}</h3>
              </div>
              <div className="flex gap-3">
                {fase.items.map((item, i) => (
                  <div key={i} className="bg-white/5 border border-white/10 rounded-lg px-4 py-2">
                    <span className="text-sm text-slate-400">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
