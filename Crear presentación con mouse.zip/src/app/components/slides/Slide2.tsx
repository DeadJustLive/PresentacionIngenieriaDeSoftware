import { motion } from 'motion/react';
import { Calendar, DollarSign, Target } from 'lucide-react';

export default function Slide2() {
  const planItems = [
    {
      icon: Target,
      label: 'Alcance',
      title: 'Automatizar e Integrar',
      description: 'Pre-digitación, validación en tiempo real e interoperabilidad institucional',
      color: 'blue'
    },
    {
      icon: Calendar,
      label: 'Tiempo',
      title: '12 Semanas',
      description: 'Ciclo iterativo con entregas incrementales y validación continua',
      color: 'cyan'
    },
    {
      icon: DollarSign,
      label: 'Costo',
      title: '$30.000.000 CLP',
      description: 'Inversión controlada con seguimiento de hitos y gestión de riesgos',
      color: 'red'
    }
  ];

  return (
    <div className="w-full h-full bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex flex-col justify-center px-20">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="mb-16"
      >
        <div className="flex items-center gap-3 mb-6">
          <div className="h-1 w-12 bg-blue-500" />
          <span className="text-blue-400 uppercase tracking-wider text-sm font-medium">
            Plan Maestro
          </span>
        </div>
        <h2 className="text-5xl font-bold text-white mb-4">
          Alcance, Tiempo y Costo
        </h2>
        <p className="text-xl text-slate-400 max-w-3xl">
          Gestión basada en metodología iterativa con control de proyecto triple restricción
        </p>
      </motion.div>

      <div className="grid grid-cols-3 gap-8 max-w-7xl">
        {planItems.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + index * 0.15, duration: 0.7 }}
            className="relative"
          >
            <div className="bg-white/5 border border-white/10 backdrop-blur-sm rounded-2xl p-8 h-full hover:bg-white/10 transition-colors">
              <div className={`w-14 h-14 rounded-xl bg-${item.color}-500/10 border border-${item.color}-500/20 flex items-center justify-center mb-6`}>
                <item.icon className={`w-7 h-7 text-${item.color}-400`} />
              </div>

              <div className="text-xs uppercase tracking-widest text-slate-500 mb-2">
                {item.label}
              </div>

              <h3 className="text-3xl font-bold text-white mb-4">
                {item.title}
              </h3>

              <p className="text-slate-400 leading-relaxed">
                {item.description}
              </p>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.6 }}
        className="mt-12 flex items-center gap-4"
      >
        <div className="flex-1 h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />
        <span className="text-slate-500 text-sm">Ciclo de Vida Iterativo</span>
        <div className="flex-1 h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent" />
      </motion.div>
    </div>
  );
}
